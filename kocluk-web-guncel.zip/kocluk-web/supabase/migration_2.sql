-- ============================================================
-- Migration 2: Daha detaylı alanlar
-- Bunu Supabase SQL Editor'de, schema.sql'den SONRA çalıştır.
-- Güvenle birden çok kez çalıştırılabilir.
-- ============================================================

alter table study_sessions add column if not exists topic text;
alter table study_sessions add column if not exists resource text;
alter table study_sessions add column if not exists efficiency int check (efficiency between 1 and 5);

alter table exam_results add column if not exists bos int not null default 0;
alter table exam_results add column if not exists exam_type text not null default 'TYT';

alter table goals add column if not exists subject text;
alter table goals add column if not exists priority text not null default 'orta' check (priority in ('düşük','orta','yüksek'));
