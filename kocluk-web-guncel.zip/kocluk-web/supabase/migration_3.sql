-- ============================================================
-- Migration 3: Müfredat (TYT/AYT konu) ilerleme takibi
-- Bunu Supabase SQL Editor'de çalıştır. Güvenle tekrar çalıştırılabilir.
-- ============================================================

create table if not exists topic_progress (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete cascade,
  exam_type text not null,        -- 'TYT' | 'AYT'
  subject text not null,          -- Ders adı
  topic text not null,            -- Konu adı
  status text not null default 'bekliyor' check (status in ('bekliyor','devam','tamam')),
  updated_at timestamptz default now(),
  unique (student_id, exam_type, subject, topic)
);

alter table topic_progress enable row level security;

drop policy if exists "topic_progress_own" on topic_progress;
create policy "topic_progress_own" on topic_progress
  for all using (student_id = auth.uid()) with check (student_id = auth.uid());

drop policy if exists "topic_progress_coach_read" on topic_progress;
create policy "topic_progress_coach_read" on topic_progress
  for select using (exists (
    select 1 from profiles p where p.id = topic_progress.student_id and p.coach_id = auth.uid()
  ));
